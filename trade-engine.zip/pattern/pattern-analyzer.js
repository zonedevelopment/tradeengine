const fs = require("fs");
const { detectMotherFishPattern } = require("./pattern-rules");

function analyzePattern(signal) {

    const weights = loadWeights();
    
    // 1. Detect Candle Pattern & Market Structure
    const result = detectMotherFishPattern({ 
        candles: signal.candles || [signal.prevCandle, signal.currentCandle].filter(Boolean)
    });

    let score = 0;

    if (result.pattern === "MOTHER_FISH_BUY") {
        score = 2;
    } else if (result.pattern === "MOTHER_FISH_SELL") {
        score = -2;
    }

    // Stop early if no pattern
    if (score === 0) {
        return {
            pattern: "NONE",
            type: "None",
            score: 0,
            strength: 0,
            structure: result.structure
        };
    }

    const research = loadMotherFishState();
    
    // Fallback to pattern name if specific type weight is missing
    const weightKey = weights[result.type] ? result.type : result.pattern;
    if (weights[weightKey]) {
        // Adjust for SELL (negative score) so weight makes it more negative
        score += (score > 0 ? weights[weightKey] : -weights[weightKey]);
    }

    if (research && Array.isArray(research.patterns)) {
        let found = research.patterns.find(p => p.type === result.type);
        if (!found) {
            found = research.patterns.find(p => p.name === result.pattern);
        }

        if (found) {
            score = score * Number(found.confidence || 1);
        }
    }

    // Overlap bonus (e.g., tight stops, high RR)
    if (signal.overlapPips && signal.overlapPips <= 200 && score !== 0) {
        score = score * 1.5;
    }

    // [NEW] Live VSA (Volume Spread Analysis) on current payload (20 candles)
    let isVolumeClimax = false;
    let isVolumeDrying = false;
    const candles = signal.candles || [];
    
    if (candles.length >= 7) {
        let totalVol = 0;
        let count = 0;
        // หาค่าเฉลี่ย Volume ของ 5 แท่งในอดีต (ไม่นับ 2 แท่งล่าสุดที่เป็นสัญญาณ)
        for (let i = candles.length - 7; i < candles.length - 2; i++) {
            if (i >= 0 && candles[i].tick_volume) {
                totalVol += Number(candles[i].tick_volume);
                count++;
            }
        }
        
        const avgVol = count > 0 ? (totalVol / count) : 0;
        
        // ดึง Volume ของ 2 แท่งล่าสุดที่เกิด Pattern
        const currVol = candles[candles.length - 1] ? Number(candles[candles.length - 1].tick_volume || 0) : 0;
        const prevVol = candles[candles.length - 2] ? Number(candles[candles.length - 2].tick_volume || 0) : 0;
        
        // ใช้ Volume ที่สูงสุดระหว่าง 2 แท่งนั้นเป็นตัวแทน (เพราะ Climax อาจเกิดที่แท่งก่อนหน้า)
        const triggerVol = Math.max(currVol, prevVol);

        if (avgVol > 0 && triggerVol >= avgVol * 1.5) {
            isVolumeClimax = true; // วอลุ่มพุ่งผิดปกติ > 1.5 เท่าของค่าเฉลี่ย (รายใหญ่เข้า)
        } else if (avgVol > 0 && triggerVol < avgVol * 0.6) {
            isVolumeDrying = true; // วอลุ่มแห้งเหือด < 60% ของค่าเฉลี่ย (หมดแรง)
        }
    }

    return {
        pattern: result.pattern,
        type: result.type || "Unknown",
        score,
        strength: result.strength || 0,
        structure: result.structure, // Structure analysis for Decision Engine
        slPrice: result.slPrice, // Dynamic SL Price
        tpPrice: result.tpPrice, // Dynamic TP Price
        isVolumeClimax, // แนบสถานะ VSA กลับไปให้ Decision Engine
        isVolumeDrying
    };

}

function loadWeights() {
    const file = "../learning/pattern-weight.json";
    if (!fs.existsSync(file)) {
        return {};
    }
    return JSON.parse(fs.readFileSync(file));
}

function loadMotherFishState() {
    const file = "../research/mother-fish-state.json";
    if (!fs.existsSync(file)) return null;
    return JSON.parse(fs.readFileSync(file, "utf8"));
}

module.exports = { analyzePattern };
