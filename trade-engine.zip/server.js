﻿require("dotenv").config();
const express = require("express");
const cron = require("node-cron");

const fs = require("fs");
const path = require("path");

const { fetchNews } = require("./news");
const { analyzeWithGemini, analyzeMotherFishWithGemini } = require("./gemini");
const { writeFilter, readFilter } = require("./filter-writer");
const { sendTelegram } = require("./telegram");

const { analyzePerformance } = require("./performance/performance-analyzer");
const { runDailyLearning } = require("./performance/daily-learner");

const { evaluateDecision, decision } =
    require("./brain/decision-engine");

const { getSession } =
    require("./brain/session-filter");

const { getRiskState, calculateDynamicRisk } =
    require("./brain/risk-manager");

const { checkCalendar, fetchCalendar } =
    require("./brain/economic-calendar");

const { analyzePattern } =
    require("./pattern/pattern-analyzer");

const { analyzeICT } =
    require("./pattern/ict-rules");

const { learnPatternWeights } =
    require("./learning/pattern-learner");

const { exec } = require("child_process");

const app = express();
app.use(express.json());

async function updateNewsAnalysis() {

    try {

        const news = await fetchNews();

        const analysis = await analyzeWithGemini(process.env.GEMINI_API_KEY, news);

        const filter = writeFilter(
            "./trade-filter.json",
            analysis
        );

    } catch (err) {
        console.log("news error", err);
    }
}

cron.schedule("* 4 * * *", updateNewsAnalysis);

cron.schedule("0 0 * * *", () => {
    learnPatternWeights();
});

// cron.schedule("*/15 * * * *", fetchCalendar);

// updateNewsAnalysis();

// fetchCalendar();

analyzePerformance();

cron.schedule("0 4 * * *", async () => {
    try {
        const result = analyzePerformance();
        await sendTelegram(
            process.env.TELEGRAM_BOT_TOKEN,
            process.env.TELEGRAM_CHAT_ID,
            `AI GOLD BOT\n\n📊 สรุปผลการเทรดประจำวัน\n\nTrades: ${result.summary.totalTrades}\nWins: ${result.summary.wins}\nLosses: ${result.summary.losses}\nWinRate: ${result.summary.winRate}%\nProfit: ${result.summary.totalProfit}`
        );
    } catch (err) {
        console.error("Performance Report Error:", err.message);
    }
});

app.post('/signal', async (req, res) => {
    const { symbol, side, price, candles, candles_h1, candles_h4, balance, overlapPips } = req.body;
    
    // [NEW] Save raw candles data with tick volume for future ML/AI training
    try {
        if (candles && candles.length > 0) {
            const dataPath = path.join(__dirname, 'data');
            if (!fs.existsSync(dataPath)) fs.mkdirSync(dataPath);
            
            const trainingDataPath = path.join(dataPath, 'candle_training_data.json');
            let trainingLogs = [];
            
            if (fs.existsSync(trainingDataPath)) {
                const raw = fs.readFileSync(trainingDataPath, 'utf-8');
                if (raw.trim() !== '') trainingLogs = JSON.parse(raw);
            }
            
            // Only keep last 2 candles to save space, but include full context
            const lastCandles = candles.slice(-3);
            
            trainingLogs.push({
                timestamp: new Date().toISOString(),
                symbol: symbol,
                price: price,
                candles: lastCandles
            });
            
            // Limit file size (keep last 5000 records)
            if (trainingLogs.length > 5000) trainingLogs.shift();
            
            fs.writeFileSync(trainingDataPath, JSON.stringify(trainingLogs, null, 2));
        }
    } catch (e) {
        console.error("Error saving training data: ", e);
    }

    const news = readFilter();
    const calendar = checkCalendar();
    const session = getSession();
    const risk = getRiskState();
    const pattern = analyzePattern({
        candles: candles,
        candlesH1: candles_h1,
        candlesH4: candles_h4,
        overlapPips: overlapPips
    });
    const ictContext = analyzeICT(candles);
    
    // Pass everything to evaluateDecision
    const evaluateResult = evaluateDecision({
        news, 
        calendar, 
        session, 
        risk,
        pattern,
        ictContext, // Pass ICT analysis to the brain
        market: {
            candlesH1: candles_h1,
            candlesH4: candles_h4,
            portfolio: req.body.portfolio || { currentPosition: "NONE", count: 0 }
        }
    });

    const score = evaluateResult.score || 0;
    let finalDecision = decision(evaluateResult);

    // [NEW] 2-Layer AI Architecture (Hybrid Veto System)
    // Only invoke Real AI (Gemini) if the code-based engine approved the trade 
    // AND we are in the Asian Session (quiet market, higher risk of fake signals)
    if ((finalDecision === "ALLOW_BUY" || finalDecision === "ALLOW_BUY_SCALP" || 
         finalDecision === "ALLOW_SELL" || finalDecision === "ALLOW_SELL_SCALP") && 
         !session.active) 
    {
        console.log("-> 🧠 Local Engine approved Asian Session trade. Requesting Gemini AI verification...");

        await sendTelegram(
            process.env.TELEGRAM_BOT_TOKEN,
            process.env.TELEGRAM_CHAT_ID,
            `🧠 Local Engine approved Asian Session trade. Requesting Gemini AI verification...`
        );
        
        try {
            // Prepare context prompt for Gemini
            const aiPrompt = `
                    You are a hedge fund AI Trading Analyst specializing in XAUUSD (Gold) during the Asian trading session (Low Volume/Quiet Market).
                    My algorithmic system (Layer 1) has detected a potential trade entry:
                    - Proposed Action: ${finalDecision}
                    - Current Price: ${price}
                    - Candlestick Pattern: ${pattern.pattern} (${pattern.type})
                    - Market Context: Trend is ${evaluateResult.trend}, Trading Mode is ${evaluateResult.mode}
                    - Fundamental News Sentiment: ${news ? news.goldImpact : 'neutral'}

                    Please analyze this setup. In low volume Asian sessions, breakouts often fail, and mean-reversion (ping-pong) works best.
                    Based on the data provided, should I execute this trade or skip it to avoid a trap?

                    Respond strictly in JSON format matching this schema:
                    {
                    "finalDecision": "${finalDecision}" or "NO_TRADE",
                    "reason": "Short explanation of your reasoning (e.g., 'Asian session breakout likely to fail, skipping.')",
                    "confidenceScore": 1-100
                    }`;
            
            const apiKey = process.env.GEMINI_API_KEY;
            let aiResponseRaw = '{"finalDecision": "' + finalDecision + '", "reason": "API Key missing, skipped", "confidenceScore": 0}';
            if (apiKey) {
                aiResponseRaw = await analyzeMotherFishWithGemini(apiKey, aiPrompt);
            }
            
            // Basic JSON extraction to handle Markdown formatting from Gemini
            let jsonString = aiResponseRaw;
            const jsonStart = aiResponseRaw.indexOf('{');
            const jsonEnd = aiResponseRaw.lastIndexOf('}');
            if (jsonStart !== -1 && jsonEnd !== -1) {
                jsonString = aiResponseRaw.substring(jsonStart, jsonEnd + 1);
            }
            
            const aiResult = JSON.parse(jsonString);
            console.log(`-> 🤖 Gemini AI Verification: ${aiResult.finalDecision} (Confidence: ${aiResult.confidenceScore}%) - Reason: ${aiResult.reason}`);
            
            // Veto override
            if (aiResult.finalDecision === "NO_TRADE") {
                finalDecision = "NO_TRADE";
                evaluateResult.reason = "VETOED_BY_GEMINI_AI: " + aiResult.reason;
            }

            await sendTelegram(
                process.env.TELEGRAM_BOT_TOKEN,
                process.env.TELEGRAM_CHAT_ID,
                `🤖 Gemini AI Verification: ${aiResult.finalDecision} (Confidence: ${aiResult.confidenceScore}%) - Reason: ${aiResult.reason}`
            );

        } catch (error) {
            console.error("Gemini AI Verification failed. Proceeding with Layer 1 decision.", error.message);
        }
    }

    let slPoints = 500;
    let tpPoints = 800;
    let lotSize = 0.01;
    let retracePoints = 0;

    // Use Dynamic SL/TP from Pattern Analysis if available (and valid distance)
    if (pattern.slPrice && price) {
        // คูณ 100 เพื่อแปลงผลต่างราคาเป็น Pips/จุด (เช่น ต่างกัน 2.50 ดอลลาร์ = 250 จุด)
        let dynamicSLPips = Math.abs(price - pattern.slPrice) * 100;
        if (dynamicSLPips > 50 && dynamicSLPips < 1500) slPoints = Math.round(dynamicSLPips);
    }
    if (pattern.tpPrice && price) {
        let dynamicTPPips = Math.abs(pattern.tpPrice - price) * 100;
        if (dynamicTPPips > 100 && dynamicTPPips < 3000) tpPoints = Math.round(dynamicTPPips);
    }

    if (score >= 8) retracePoints = 0;
    else if (score >= 5) retracePoints = 40;
    else retracePoints = 60;

    const hour = new Date().getHours();
    // Only override with time-based rules if we didn't get dynamic TP/SL
    if (!pattern.slPrice && !pattern.tpPrice) {
        if (hour >= 19 && hour <= 23) { slPoints = 300; tpPoints = 500; }
        else if (hour >= 7 && hour <= 8) { tpPoints = 200; slPoints = 200; }
    }
    if (balance && balance > 0) {
        // Use Dynamic Risk based on pattern & mode
        const riskPercent = calculateDynamicRisk(score, pattern.type, evaluateResult.mode, 2.0);
        const riskAmount = balance * (riskPercent / 100);
        let calculatedLot = riskAmount / slPoints;
        lotSize = Number(calculatedLot.toFixed(2));
        if (lotSize < 0.01) lotSize = 0.01;
        if (lotSize > 5.0) lotSize = 5.0;
    }

    // Apply Scalp tweaks to SL/TP ONLY if they weren't dynamically calculated by pattern analysis
    if (evaluateResult.mode === "SCALP" && !pattern.slPrice && !pattern.tpPrice) {
        slPoints = Math.round(slPoints * 0.7);
        tpPoints = Math.round(tpPoints * 0.8);
    }

    return res.json({
        decision: finalDecision,
        score: score,
        mode: evaluateResult.mode || "NORMAL",
        trend: evaluateResult.trend || "NEUTRAL",
        pattern: pattern,
        trade_setup: {
            recommended_lot: lotSize,
            sl_points: slPoints,
            tp_points: tpPoints,
            retrace_points: retracePoints
        }
    });
});

app.post("/trade-event", async (req, res) => {
    const { type, symbol, side, lot, price, sl, tp, profit, mode } = req.body;
    console.log(req.body);

    let message = "";

    if (type === "OPEN_ORDER") {
        message = `🟢 เปิดออเดอร์ใหม่ (${mode})\n\nSide: ${side}\nLot: ${lot}\n\nEntry: ${price}\nSL: ${sl}\nTP: ${tp}`;
    }

    if (type === "CLOSE_ORDER") {
        message = `🔴 ปิดออเดอร์แล้ว (${mode})\n\nSide: ${side}\n\nProfit: ${profit}`;
    }

    if (type === "WAIT_ORDER") {
        message = `🔘 รอเปิดออเดอร์ (${mode})\n\nSide: ${side}\nLot: ${lot}\n\nEntry: ${price}\nSL: ${sl}\nTP: ${tp}`;
    }

    if (type === "CANCEL_ORDER") {
        message = `⚫ ยกเลิกออเดอร์ (${mode})\n\nSide: ${side}\nLot: ${lot}\n\nEntry: ${price}\nSL: ${sl}\nTP: ${tp}`;
    }

    await sendTelegram(
        process.env.TELEGRAM_BOT_TOKEN,
        process.env.TELEGRAM_CHAT_ID,
        message
    );

    const historyFile = path.join(__dirname, "data", "trade-history.json");
    let history = [];

    if (fs.existsSync(historyFile)) {
        const raw = fs.readFileSync(historyFile, "utf8").trim();
        if (raw) {
            history = JSON.parse(raw);
        }
    }

    history.push(req.body);
    fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));

    // [New] Send data for Post-Trade Analysis (Mae Pla Pakka Keaw)
    if (type === "CLOSE_ORDER") {
        const maePlaLogPath = path.join(__dirname, "data", "mae_pla_logs.json");
        let maePlaLogs = [];
        if (fs.existsSync(maePlaLogPath)) {
            const rawLog = fs.readFileSync(maePlaLogPath, "utf-8");
            if (rawLog.trim() !== '') maePlaLogs = JSON.parse(rawLog);
        }

        maePlaLogs.push({
            timestamp: new Date().toISOString(),
            type: "trade_result",
            ticket_id: req.body.ticket_id || Date.now(),
            result: parseFloat(profit) > 0 ? "TP" : "SL",
            pnl_pips: parseFloat(profit),
            market_conditions_at_entry: {
                symbol: symbol,
                side: side
            },
            lesson_learned: parseFloat(profit) > 0
                ? "Trade successful. Align with Mae Pla rules."
                : "Trade failed. Need to review entry condition or market session."
        });

        fs.writeFileSync(maePlaLogPath, JSON.stringify(maePlaLogs, null, 2));
    }

    analyzePerformance();
    res.json({ success: true });
});

app.post('/webhook/mae-pla', async (req, res) => {
    try {
        const payload = req.body;
        console.log(`[Mae Pla Webhook] Received type: ` + payload.type);

        const dataPath = path.join(__dirname, 'data');
        if (!fs.existsSync(dataPath)) {
            fs.mkdirSync(dataPath);
        }

        const logPath = path.join(dataPath, 'mae_pla_logs.json');

        let logs = [];
        if (fs.existsSync(logPath)) {
            const raw = fs.readFileSync(logPath, 'utf-8');
            if (raw.trim() !== '') logs = JSON.parse(raw);
        }

        logs.push(payload);
        fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));

        if (payload.type === 'market_context') {
            console.log('-> Market Context Updated: recommendation =', payload.recommendation);
        } else if (payload.type === 'signal_validation') {
            console.log('-> Signal Validation:', payload.action, 'Score:', payload.ai_confidence_score);
        } else if (payload.type === 'trade_result') {
            console.log('-> Trade Learning Logged:', payload.result, 'Lesson:', payload.lesson_learned);
        }

        res.json({ success: true, message: 'Mae Pla data logged & processed' });
    } catch (error) {
        console.error('Webhook Error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});


// ==========================================
// [NEW] OpenClaw AI Autonomous Cron Jobs
// ==========================================

// 04:30 - Daily Internal Mapping and Learning (Backend ML)
cron.schedule("30 4 * * *", () => {
    runDailyLearning();
});

// 06:00 - Morning Brief
cron.schedule("0 6 * * *", () => {
    console.log("[AI Cron] Waking up AI for Morning Brief...");
    exec('openclaw chat "สรุปข่าวเศรษฐกิจ XAUUSD ของวันนี้ และส่ง news_filter เข้า webhook"');
});

// 07:00 - Asian Session (Sideway)
cron.schedule("0 7 * * *", () => {
    console.log("[AI Cron] Waking up AI for Asian Session...");
    exec('openclaw chat "ส่ง market_context บอก EA ให้ระวัง Sideway บีบตัว หรือ pause_ea"');
});

// 14:00 - London Pre-Open
cron.schedule("0 14 * * *", () => {
    console.log("[AI Cron] Waking up AI for London Session...");
    exec('openclaw chat "ประเมินโครงสร้าง H1/H4 ปัจจุบัน แล้วส่ง market_context อนุญาตให้ EA กลับมาเทรด (active)"');
});

// 18:00 - US Pre-Open
cron.schedule("0 18 * * *", async () => {
    console.log("[AI Cron] Waking up AI for US Session...");
    exec('openclaw chat "อัปเดตข่าวค่ำนี้ และเตรียมขยับ SL/TP ของ EA เป็น 300/500 จุดผ่าน webhook"');
});

// 23:30 - Daily Review
cron.schedule("30 23 * * *", () => {
    console.log("[AI Cron] Waking up AI for Daily Review...");
    exec('openclaw chat "สรุปบทเรียนจากไม้ที่ปิดไปวันนี้ใน mae_pla_logs.json และหาจุดอ่อนเพื่อปรับปรุงระบบ"');
});

app.listen(5000, () => {
    console.log("Trading AI Engine running");
});
